Dumbster was an open source project hosted at Sourceforge. Unfortunately, that project has not had any commits
to it since 2005. The code was copied here to be able to address a race condition in SimpleSmtpServer.

Dumbster is Copyright 2004 Jason Paul Kitchen